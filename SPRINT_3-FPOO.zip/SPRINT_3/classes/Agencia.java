package classes;

import java.io.Serializable;

public class Agencia implements Serializable {
	public String login;
	public String senha;
	
	//Construtor
	public Agencia(String login, String senha) {
		super();
		this.login = login;
		this.senha = senha;
	}
}

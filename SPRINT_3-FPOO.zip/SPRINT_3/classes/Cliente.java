package classes;

public class Cliente {
	
	// DECLARA��O + TIPO DAS VARIAVEIS
		public String nome;        //NOME A SER DIGITADO PELO CLIENTE
		public String email;       //EMAIL A SER DIGITADO PELO CLIENTE
		public String telefone;    //TELEFONE A SER DIGITADO PELO CLIENTE
		public int idade;
		public String genero;
		
		//CONTRUTOR - � FEITO CLICANDO EM SOURCE -> GENERATE CONSTRUCTOR USING FIELDS
		public Cliente(String nome, String email, String telefone, int idade, String genero) {
			super();
			this.nome = nome;
			this.email = email;
			this.telefone = telefone;
			this.idade = idade;
			this.genero = genero;
		}
		// METODO PARA  MOSTRAR DADOS
		public String mostrarDados() {
			return  "\n-------------------------------------" +
					"\nNome : " + this.nome +
					"\nE-mail: " + this.email +
					"\nIdade: " + this.idade +
					"\nTelefone: " + this.telefone +
			        "\nG�nero: " + this.genero;
		}
}

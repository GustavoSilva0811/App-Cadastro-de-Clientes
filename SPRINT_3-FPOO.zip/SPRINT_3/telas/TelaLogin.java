package telas;

import java.awt.Color;
import java.awt.HeadlessException;
import java.awt.Image;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Iterator;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPasswordField;
import javax.swing.JTextField;

import arquivo.LerEscreverObjeto;
import classes.Agencia;

public class TelaLogin extends JFrame {
	private JLabel jlLogin,jlSenha;
	private JTextField jtfLogin;
	private JPasswordField jpfSenha;
	private JButton jbLogar, jbCadastrar;
	private Agencia[] clientes = new Agencia[40];
	private Agencia[] clientesLer = new Agencia[40];
	private int indice = 0;

	public TelaLogin(String title) throws HeadlessException {
		super(title);
		setSize(250, 250);//tamanho da tela
		setLayout(null);//desabilita o dimensionamento autom�tico do java
		getContentPane().setBackground(Color.yellow);
		setLocationRelativeTo(this);//Tela centralizada
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);//fecha a janela e encerra o programa 
		iniciarComponente();
		lerArquivo();
		criarEventos();
	}
	
	private Agencia[] lerArquivo() {
		LerEscreverObjeto ler = new LerEscreverObjeto("Cliente.bin");
		
		clientesLer = ler.LerEscreverObjeto();
		return clientesLer;
	}

	private void iniciarComponente() {
		java.net.URL url = this.getClass().getResource("/imagens/Logo.png");
		Image iconeTitulo = Toolkit.getDefaultToolkit().getImage(url);
		this.setIconImage(iconeTitulo);
		
		jlLogin = new JLabel("login");
		jlSenha = new JLabel("Senha");
		jtfLogin = new JTextField();
		jpfSenha = new JPasswordField();
		jbLogar = new JButton("Logar");
		jbCadastrar = new JButton("Cadastrar");
		
		//Adicionar
		add(jlLogin);
		add(jlSenha);
		add(jtfLogin);
		add(jpfSenha);
		add(jbCadastrar);
		add(jbLogar);
		
		//Dimencionar
		jlLogin.setBounds(80, 10, 50, 20);
		jtfLogin.setBounds(80, 30, 80, 20);
		jlSenha.setBounds(80, 60, 80, 20);
		jpfSenha.setBounds(80, 80, 80, 20);
		jbLogar.setBounds(70, 110, 100, 20);
		jbCadastrar.setBounds(70, 140, 100, 20);
		
	}

	private void criarEventos() {
		//Bot�o Cadastrar
		jbCadastrar.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				TelaCadastro cadastro = new TelaCadastro("Cadastro", clientes,indice);
				cadastro.setVisible(true);
				indice++;
			}
		});

		jbLogar.addActionListener(new ActionListener() {


		        @Override

		        public void actionPerformed(ActionEvent e) {

		            if (!jtfLogin.getText().isEmpty() && !String.valueOf(jpfSenha.getPassword()).isEmpty()) {

		            if (clientes != null) {

		                for (Agencia clientes : clientes) {

		                    if (clientes != null) {

		                        if (clientes.login.equals(jtfLogin.getText()) && clientes.senha.equals(String.valueOf(jpfSenha.getPassword()))) {

		                            TelaCliente cliente = new TelaCliente("NOVO CLIENTE");

		                            cliente.setVisible(true);

		                            setVisible(false);// Deixa a tela login invisivel

		                            break;

		                    }

		                  }

		                }    

		            } else {

		                JOptionPane.showMessageDialog(null,

		                        "Nenhum us�rio cadastrado", 

		                        "Login", JOptionPane.WARNING_MESSAGE);

		            }

		         }else {

		                JOptionPane.showMessageDialog(null, "Preencha todos os Campos", "Login", JOptionPane.WARNING_MESSAGE);

		            }

		        }

		    });// Fim do Bot�o Logar});
	}
	public static void main(String[] args) {
		TelaLogin login = new TelaLogin("Login");
		login.setVisible(true);
	}
}

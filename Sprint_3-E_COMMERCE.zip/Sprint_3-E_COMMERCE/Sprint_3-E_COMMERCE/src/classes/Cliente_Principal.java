package classes;

import javax.swing.JOptionPane;

public class Cliente_Principal {

	public static void main(String[] args) {
		//Declara��o de Vari�veis
		String[] menu= {"Cadastrar", "Pesquisar", "Mostrar", "Sair"};//Vetor est�tico
		String opcao=null;
		Cliente cliente = null;
		
		do {
			//Vari�vel que armazena valor de escolha do menu
			opcao = (String) JOptionPane.showInputDialog(null, "Escolha uma op��o", "Cadastro de Clientes - VIAMAR", JOptionPane.INFORMATION_MESSAGE, null, menu, "Cadastrar");
			
			//La�o de repeti��o
			switch (opcao) {
			case "Cadastrar":
				String nome, email, telefone;
				
				//Entradas do Sistema
				nome = JOptionPane.showInputDialog(null, "Nome de Cadastro", "Nome do Cliente",JOptionPane.INFORMATION_MESSAGE);
				email = JOptionPane.showInputDialog(null, "Email de Cadastro", "Email do Cliente",JOptionPane.INFORMATION_MESSAGE);
				telefone = JOptionPane.showInputDialog(null, "Telefone de Cadastro", "Telefone do Cliente",JOptionPane.INFORMATION_MESSAGE);
				
				//Criando o objeto da classe Cliente a ser usado atrav�s do construtor
				cliente = new Cliente(nome, email, telefone);
				
				//Imagem de sa�da para cadastro conclu�do
				JOptionPane.showMessageDialog(null, "Cliente Cadastrado", "Cadastro de Clientes", JOptionPane.YES_NO_CANCEL_OPTION);
				
				break;
			case "Pesquisar":
				//Comparativo com os nomes j� cadastrados, Processamento e Sa�da
				String nome_pesquisa;//Nome que ser� inserido para verificar se condiz com o valor armazenado no cadastro
				
				//Entrada do Sistema
				nome_pesquisa = JOptionPane.showInputDialog(null, "Insira o nome a ser pesquisado", "Consulta de Clientes",JOptionPane.INFORMATION_MESSAGE);
				
				//Valida��o da op��o
				if (nome_pesquisa.equals(cliente.nome)) {
					JOptionPane.showMessageDialog(null, cliente.mostrarDados(), "Consulta de Clientes", JOptionPane.INFORMATION_MESSAGE);
				} else {
					
				}
				
				break;
			case "Mostrar":
				//Sa�da do Sistema por meio da op��o mostrar
				JOptionPane.showMessageDialog(null, cliente.mostrarDados(), "Consulta de Clientes",JOptionPane.INFORMATION_MESSAGE);
				break;
			}
			
		} while (!opcao.equals("Sair"));//Caso aconte�a isso, valor da vari�vel igual a "Sair", encerrar� o sistema

	}

}
package classes;

public class Cliente{
	
	// DECLARA��O + TIPO DAS VARIAVEIS
		public String nome;        //NOME A SER DIGITADO PELO CLIENTE
		public String email;       //EMAIL A SER DIGITADO PELO CLIENTE
		public String telefone;    //TELEFONE A SER DIGITADO PELO CLIENTE
		
		//CONTRUTOR - � FEITO CLICANDO EM SOURCE -> GENERATE CONSTRUCTOR USING FIELDS
		public Cliente(String nome, String email, String telefone) {
			super();
			this.nome = nome;
			this.email = email;
			this.telefone = telefone;
		}
		// METODO PARA  MOSTRAR DADOS
		public String mostrarDados() {
			return "Nome : " + this.nome +
					"\nE-mail: " + this.email +
					"\nTelefone: " + this.telefone;
		}
}
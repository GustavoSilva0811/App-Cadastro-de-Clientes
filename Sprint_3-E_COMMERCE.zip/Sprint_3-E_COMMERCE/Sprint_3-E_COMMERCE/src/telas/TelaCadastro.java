package telas;

import java.awt.Color;

import java.awt.HeadlessException;
import java.awt.Image;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPasswordField;
import javax.swing.JTextField;

import arquivo.LerEscreverObjeto;
import classes.Agencia;

public class TelaCadastro extends JFrame {
	private JLabel jlLogin,jlSenha;
	private JTextField jtfLogin;
	private JPasswordField jpfSenha;
	private JButton jbCadastrar;
	private Agencia[] clientes;
	private int indice;

	public TelaCadastro(String title, Agencia[] clientes, int indice) throws HeadlessException {
		super(title);
		this.clientes = clientes;
		this.indice = indice;
		setSize(250, 250);//tamanho da tela
		setLayout(null);//desabilita o dimensionamento autom tico do java
		getContentPane().setBackground(Color.LIGHT_GRAY);
		setLocationRelativeTo(this);//Tela centralizada
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);//fecha a janela e encerra o programa 
		iniciarComponente();
		criarEventos();
	}


	private void iniciarComponente() {
		java.net.URL url = this.getClass().getResource("/imagens/Logo.png");
		Image iconeTitulo = Toolkit.getDefaultToolkit().getImage(url);
		this.setIconImage(iconeTitulo);
		
		jlLogin = new JLabel("login");
		jlSenha = new JLabel("Senha");
		jtfLogin = new JTextField();
		jpfSenha = new JPasswordField();
		jbCadastrar = new JButton("Cadastrar");
		
		//Adicionar
		add(jlLogin);
		add(jlSenha);
		add(jtfLogin);
		add(jpfSenha);
		add(jbCadastrar);
		
		
		//Dimencionar
		jlLogin.setBounds(80, 10, 50, 20);
		jtfLogin.setBounds(80, 30, 80, 20);
		jlSenha.setBounds(80, 60, 80, 20);
		jpfSenha.setBounds(80, 80, 80, 20);
		jbCadastrar.setBounds(70, 140, 100, 20);
		
	}

	private void criarEventos() {
		
		jbCadastrar.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub

				String login = jtfLogin.getText();
				String senha = String.valueOf(jpfSenha.getPassword()); // Converte um conjunto de Caractere para Sring.
				if (!jtfLogin.getText().isEmpty() && !String.valueOf(jpfSenha.getPassword()).isEmpty()) {
				for (int i = 0; i < clientes.length; i++) {
				if (clientes[i] == null) {
				clientes[i] = new Agencia(login, senha);
				setVisible(false);
				LerEscreverObjeto gravar = new LerEscreverObjeto("Cliente.bin");
				gravar.escreverObjeto(clientes);
				
				break;
				}
				}
				}else {
				JOptionPane.showMessageDialog(null, "Preencha todos os Campos", "Cadastro", JOptionPane.WARNING_MESSAGE);
				}
				}

				});// Fim do Bot�o Cadastrar
		
	}
}
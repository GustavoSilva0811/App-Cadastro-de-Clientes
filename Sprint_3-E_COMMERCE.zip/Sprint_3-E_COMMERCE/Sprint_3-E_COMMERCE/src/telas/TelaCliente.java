package telas;

import java.awt.Color;
import java.awt.HeadlessException;
import java.awt.Image;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.print.DocFlavor.URL;

import javax.swing.ButtonGroup;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JRadioButton;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;

import classes.Cliente;

public class TelaCliente extends JFrame {
	private JLabel jlNome,jlPeso,jlIdade, jlGenero,jlImagem;
	private JTextField jtfNome,jtfIdade;
	private JButton jbCadastrar,jbMostrar;
	private JTextArea jtaMostrar; //Usado para grande textos
	private JScrollPane jspMostrar;//Barra de rolagem
	private JRadioButton jrbMasculino,jrbFeminino;
	private ButtonGroup bgGenero; //Agrupa os radios buttons para que seja selecionado*
	private ImageIcon imagem;
	private Cliente[] clientes = new Cliente[40];
	private int indice = 0;
	

	public TelaCliente(String title) throws HeadlessException {
		super(title);
		setSize(400, 400);//tamanho da tela
		setLayout(null);//desabilita o dimensionamento autom tico do java
		getContentPane().setBackground(Color.GRAY);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);//fecha a janela e encerra o programa 
		iniciarComponente();
		criarEventos();
	}

	private void iniciarComponente() {
		java.net.URL url = this.getClass().getResource("/imagens/Logo.png");
		Image iconeTitulo = Toolkit.getDefaultToolkit().getImage(url);
		this.setIconImage(iconeTitulo);
		
		// objeto
		imagem = new ImageIcon(getClass().getResource("/imagens/Logo.png"));
		jlImagem = new JLabel(imagem);//JLabel suportando uma imagem
		jlNome = new JLabel("Nome");
		
		jlIdade = new JLabel("idade");
		jlGenero = new JLabel("Genero");
		jtfNome = new JTextField();
		
		jtfIdade = new JTextField();
		jbCadastrar = new JButton("Cadastrar");
		jbMostrar = new JButton("Mostrar");
		jtaMostrar = new JTextArea();
		jspMostrar = new JScrollPane(jtaMostrar);
		jrbMasculino = new JRadioButton("Masculino", true);
		jrbMasculino.setOpaque(false);
		jrbFeminino = new JRadioButton("Feminino");
		jrbFeminino.setOpaque(false);
		bgGenero = new ButtonGroup();
		
		
		//adicionar
		add(jlNome);
		add(jtfNome);
		
		
		add(jlIdade);
		add(jtfIdade);
		add(jbCadastrar);
		add(jbMostrar);
		add(jrbMasculino);
		add(jrbFeminino);
		add(jlGenero);
		add(jspMostrar);
		add(jlImagem);
		bgGenero.add(jrbFeminino);
		bgGenero.add(jrbMasculino);
	
		
		//dimensionamento
		jlNome.setBounds(10, 40, 50, 20);
		jtfNome.setBounds(10, 60, 200, 20);
		
		jlIdade.setBounds(160, 90, 50, 20);
		jtfIdade.setBounds(160, 110, 50, 20);
		jbCadastrar.setBounds(10, 140, 100, 20);
		jbMostrar.setBounds(130, 140, 80, 20);
		jlGenero.setBounds(270, 90, 100, 20);
		jrbMasculino.setBounds(250, 110, 100, 20);
		jrbFeminino.setBounds(250, 130, 100, 20);
		jspMostrar.setBounds(10, 170, 350, 160);
		jlImagem.setBounds(220, 10, 80, 80);
		
		
	}

	private void criarEventos() {
		// Criar evento do bot o cadastrar
		jbCadastrar.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				String nome,genero;
				
				int idade;
				//Entradas
				nome = jtfNome.getText();
				
				idade = Integer.parseInt(jtfIdade.getText());
				if (jrbMasculino.isSelected()) {
					genero = "Masculino";
				} else {
					genero = "Feminino";
				}
				 //Genero = jrbMasculino.isSelected()? "Masculino : "Feminino";
				//Objeto
				clientes[indice] = new Cliente(nome, nome, genero);
				indice++;
				//Apagar campos
				jtfNome.setText("");
				
				jtfIdade.setText("");
				
			}
		});
			
				//Criar evento bot o mostrar
				jbMostrar.addActionListener(new ActionListener() {
					
					@Override
					public void actionPerformed(ActionEvent e) {
						jtaMostrar.setText("\t Cadastro de Clientes\n\n");
						if (clientes[0] != null) {
							for (int i =0; i < indice; i++) {
								jtaMostrar.append(clientes[i].mostrarDados() + "\n"+clientes[i].mostrarDados());
							}
						} else {
							JOptionPane.showMessageDialog(null, "Nenhum cliente foi cadastrado", "Cadastro de Cliente", JOptionPane.WARNING_MESSAGE);
						}
					}

		});
		
	}
}
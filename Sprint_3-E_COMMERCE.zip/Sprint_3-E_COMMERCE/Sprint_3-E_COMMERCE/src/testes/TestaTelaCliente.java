package testes;


import telas.TelaCliente;

public class TestaTelaCliente {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		TelaCliente cliente = new TelaCliente("Cadastro de Clientes");
		cliente.setVisible(true);
		
	}

}